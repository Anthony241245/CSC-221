import pandas as pd


def prepare_df(csv_file, index):
    # Read in csv file as panadas df    
    
   df = pd.read_csv("deansDailyCsar.csv", index_col='Sec Name')
   #print(df)
   df = df.loc[~df.index.duplicated(keep='first')]
   print()
   #print("After removing duplicate rows....")
   #print(df)
   print()
   #print("Dataset is now sorted")
   # Reset the index using multiple columns
   df_reset = df.reset_index(drop=False)
   df_sorted = df_reset.sort_values(by=['Sec Divisions', 'Sec Name', 'Sec Faculty Info'])
   #print(df_sorted)
   
   # Write the sorted df to a csv file
   df_sorted.to_csv("sorted.csv", index=True)
   return df_sorted


def main():
    # Call the function to get the sorted df
    df = prepare_df("deansDailyCsar.csv", "Sec Name")
    print(df)
    
    
    
   
   
   
    
    
if __name__ == "__main__":
     main()