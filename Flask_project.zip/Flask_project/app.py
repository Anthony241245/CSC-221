from flask import Flask, render_template, send_from_directory


app = Flask(__name__)

@app.route("/")
def index():
    message = "World"
    return render_template("index.html", message=message)

