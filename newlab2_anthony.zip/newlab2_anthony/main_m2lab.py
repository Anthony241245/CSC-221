# Anthony Raynor
# 3/20/25
# M2Lab
# Use pandas to read and edit csv files
import pandas as pd

# function to read in a csv file
def read_csv(filename, index):
    df = pd.read_csv(filename)
    df = df.set_index(index)
    print(df)
    return df
    
def main():
    df = read_csv("djia.csv", "Symbol")
    print(df.info())
    print(df.shape)
    
    # Show first 5 rows
    print(df.head())
    
    print()
    print()
    
    # show first 7 rows
    print(df.tail(7))
    
    # Display Company Column
    print(df['Company'])
    
    # Create new df from 2 existing columns
    new_df = df[['Company', 'Industry']]
    print(new_df)
    
    # Display data for row where Symbol is AAPL
    AAPL_df = df.loc['AAPL']
    print(AAPL_df)
    print()
    print(AAPL_df['Exchange'])
    print()
    print()
    print("Dataframe sorted by the industry and company")
    # Display the data sorted by the industry company then company
    sort_df = df.sort_values(by=['Industry', 'Company'])
    print(sort_df)
    print()
    print()

    # Display the rows where Industry is information Techonology
    IT_df = df.loc[df['Industry'] == "Information technology"]
    print(IT_df)
    print()
    print()
    print("ALl rows where notes are not empty")
    # Display rows where notes has a value (not NaN)
    has_notes_df = df.loc[df["Notes"].notna()]
    print(has_notes_df)

    # create and display a data frame from the full df exculding the notes column
    pd.set_option("display.max_columns", None)
    df_wo_notes = df.drop(columns=["Notes"])
    df_wo_notes2 = df.drop("Notes", axis=1)
    print()
    print("Dataframes without notes")
    print(df_wo_notes)
    print(df_wo_notes2)

    # Join the two csv files together
    prices_df = read_csv("djia-prices.csv", "Symbol")

    joined_df = df.join(prices_df)
    print()
    print()
    print("Display joined Dataframes")
    print(joined_df)

    # write joined dataframe to csv
    joined_df.to_csv("joined.csv",index=False)


    
    
    
    
# Call main
if __name__ == "__main__":
    main()
    


