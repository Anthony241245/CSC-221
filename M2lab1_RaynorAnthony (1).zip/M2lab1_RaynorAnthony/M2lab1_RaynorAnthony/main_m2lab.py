# Anthony Raynor
# 3/20/25
# M2Lab
# Use pandas to read and edit csv files
import pandas as pd

# Function to write student data to a CSV file
def write_csv(filename):
    data = {
        "Student Name": ["Zakari Watson", "Jeromi Williams", "Dominique Ross", "Alex Johnson"],
        "GPA": [3.8, 3.6, 3.9, None],  # Alex Johnson not enrolled
        "Tuition": [5000, 4800, 5100, 0]  # 0 tuition for non-enrolled student
    }

    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)
    print(f"Data saved to {filename}")

# Function to read student data from a CSV file
def read_csv(filename):
    try:
        df = pd.read_csv(filename)
        print(df)
        return df
    except FileNotFoundError:
        print("File not found. Please run option 1 first.")
        return None

# Display students with an associated integer value
def display_students(df):
    if df is None:
        return
    print("\nStudents:")
    for i, student in enumerate(df["Student Name"], start=1):
        print(f"{i}) {student}")

# Show tuition for a selected student
def show_tuition(df):
    if df is None:
        return
    display_students(df)
    try:
        choice = int(input("\nEnter the number of the student: "))
        if 1 <= choice <= len(df):
            student_name = df.iloc[choice - 1]["Student Name"]
            tuition = df.iloc[choice - 1]["Tuition"]
            print(f"\n{student_name}'s Tuition: ${tuition}")
        else:
            print("Invalid choice.")
    except ValueError:
        print("Please enter a valid number.")

# Read file and display total tuition
def display_total_tuition(df):
    if df is None:
        return
    print("\nStudent Data:")
    total_tuition = df["Tuition"].sum()
    print(df)
    print(f"\nTotal Tuition for all students: ${total_tuition}")

# Main function
def main():
    filename = "students.csv"
    df = None

    while True:
        print("\nMenu:")
        print("1) Save students to file")
        print("2) Display students")
        print("3) Show tuition for a student")
        print("4) Read file and display tuition details")
        print("5) Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            write_csv(filename)
        elif choice == "2":
            df = read_csv(filename)
            display_students(df)
        elif choice == "3":
            df = read_csv(filename)
            show_tuition(df)
        elif choice == "4":
            df = read_csv(filename)
            display_total_tuition(df)
        elif choice == "5":
            print("Exiting program.")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()

